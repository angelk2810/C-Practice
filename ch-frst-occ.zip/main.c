#include<stdio.h>
#include<string.h>
int main(){
    char str[100];
    scanf("%s",str);
    
    int length=0;
    length=strlen(str);
    
    char a;
    scanf("%s",&a);
    
    for(int i=0; i<length; i++){
        if(str[i]==a){
            printf("%d",i+1);
            break;
        }
    }
    
    return 0;
}